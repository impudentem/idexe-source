<?php
$_['heading_title']					= 'CodeManager';
$_['menu_title']					= 'CodeManager';
$_['error_permission']				= 'Warning: You do not have permission to modify module CodeManager!';
$_['text_success']					= 'Success: You have modified module CodeManager!';
$_['text_enabled']					= 'Enabled';
$_['text_disabled']					= 'Disabled';
$_['button_cancel']					= 'Cancel';
$_['save_changes']					= 'Grant temporary access details';
$_['text_default']					= 'Default';
$_['text_module']					= 'Module';
