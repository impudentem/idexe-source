<?php
// Text

                //Callback and Feedback
				$_['entry_fo_button']                             = 'Callback';
				$_['entry_fo_button2']                            = 'Write a letter';
				$_['entry_fo_name']                               = 'Your name';
				$_['entry_fo_name_error']                         = 'Please write how to contact you';
				$_['entry_fo_email']                              = 'Your Email';
				$_['entry_fo_email_error']                        = 'Please tell us your Email';
				$_['entry_fo_phone']                              = 'Your phone:';
				$_['entry_fo_phone_error']                        = 'Please provide your phone number';
				$_['entry_fo_close']                              = 'Close';
				$_['entry_fo_message'] 							  = 'Message';
				$_['entry_fo_send']                               = 'Order callback';
				$_['entry_fo_send2']                              = 'Send';
				$_['entry_fo_send_success']                       = 'Your question has be sent!<br />Manager will contact you as soon as possible.';
				$_['entry_fo_send_error']                         = 'Request could not be sent.<br />Contact us in any other convenient way.';
                
$_['text_home']          = 'Home';
$_['text_wishlist']      = 'Wish List (%s)';
$_['text_shopping_cart'] = 'Shopping Cart';
$_['text_category']      = 'Categories';
$_['text_account']       = 'My Account';
$_['text_register']      = 'Register';
$_['text_login']         = 'Login';
$_['text_order']         = 'Order History';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Checkout';
$_['text_search']        = 'Search';
$_['text_all']           = 'Show All';
$_['text_about']         = 'About Us';
$_['text_blog']          = 'Blog';
$_['text_catalog']       = 'Cataloge';
$_['text_shops']         = 'Shops';
$_['text_delivery']      = 'Shipping and payment';
$_['text_contacts']      = 'Contacts';
$_['text_special']       = 'Specials';
$_['text_actions']       = 'Actions';
$_['text_news']          = 'News';
$_['text_franchise']     = 'Franchise';