<?php
$_['codemanager_path'] = 'extension/module/codemanager';
$_['codemanager_model'] = 'model_extension_module_codemanager';
$_['codemanager_name'] = 'codemanager';
$_['codemanager_version'] = '2.2.5';