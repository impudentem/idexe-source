<?php
class HtmlDomComment {
    public $text;

    public function __construct($txt) {
        $this->text = $txt;
    }
}
