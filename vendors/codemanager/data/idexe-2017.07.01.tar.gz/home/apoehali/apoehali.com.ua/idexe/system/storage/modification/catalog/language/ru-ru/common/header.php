<?php
// Text

                //Callback and Feedback
				$_['entry_fo_button']                             = 'Обратный звонок';
				$_['entry_fo_button2']                            = 'Написать письмо';
				$_['entry_fo_name']                               = 'Ваше имя';
				$_['entry_fo_name_error']                         = 'Пожалуйста, напишите как к Вам обращаться';
				$_['entry_fo_email']                              = 'Ваш Email';
				$_['entry_fo_email_error']                        = 'Пожалуйста, сообщите свой Email';
				$_['entry_fo_phone']                              = 'Ваш телефон:';
				$_['entry_fo_phone_error']                        = 'Пожалуйста, сообщите свой номер телефона';
				$_['entry_fo_close']                              = 'Закрыть';
				$_['entry_fo_message'] 							  = 'Сообщение';
				$_['entry_fo_send']                               = 'Заказать обратный звонок';
				$_['entry_fo_send2']                              = 'Отправить';
				$_['entry_fo_send_success']                       = 'Ваш запрос успешно отправлен!<br />Менеджер свяжется с Вами в ближайшее время.';
				$_['entry_fo_send_error']                         = 'Запрос не может быть отправлен.<br />Свяжитесь с нами любым другим удобным способом.';
                
$_['text_home']          = 'Главная';
$_['text_about']         = 'О компании';
$_['text_wishlist']      = 'Закладки (%s)';
$_['text_shopping_cart'] = 'Корзина';
$_['text_category']      = 'Категории';
$_['text_account']       = 'Личный кабинет';
$_['text_register']      = 'Регистрация';
$_['text_login']         = 'Вход';
$_['text_order']         = 'История заказов';
$_['text_transaction']   = 'Транзакции';
$_['text_download']      = 'Загрузки';
$_['text_logout']        = 'Выход';
$_['text_checkout']      = 'Оформление заказа';
$_['text_search']        = 'Поиск';
$_['text_all']           = 'Смотреть Все';
$_['text_blog']          = 'Блог';
$_['text_catalog']       = 'Каталог';
$_['text_shops']         = 'Адреса магазинов';
$_['text_delivery']      = 'Доставка и оплата';
$_['text_contacts']      = 'Контакты';
$_['text_special']      = 'Распродажа';
$_['text_actions']       = 'Акции';
$_['text_news']          = 'Новости';
$_['text_franchise']     = 'Франшиза';
