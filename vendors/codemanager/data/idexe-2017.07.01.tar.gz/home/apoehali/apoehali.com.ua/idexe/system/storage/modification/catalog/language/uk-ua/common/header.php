<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text

                 //Callback and Feedback
				$_['entry_fo_button'] = 'Зворотній дзвінок';
				$_['entry_fo_button2'] = 'Написати листа';
				$_['entry_fo_name'] = "Ваше ім'я";
				$_['entry_fo_name_error'] = 'Будь ласка, напишіть як до Вас звертатися';
				$_['entry_fo_email'] = 'Ваш Email';
				$_['entry_fo_email_error'] = 'Будь ласка, повідомте свій Email';
				$_['entry_fo_phone'] = 'Ваш телефон:';
				$_['entry_fo_phone_error'] = 'Будь ласка, повідомте свій номер телефону';
				$_['entry_fo_close'] = 'Закрити';
				$_['entry_fo_message'] = 'Повідомлення';
				$_['entry_fo_send'] = 'Замовити зворотний дзвінок';
				$_['entry_fo_send2'] = 'Відправити';
				$_['entry_fo_send_success'] = "Ваш запит успішно відправлений! <br /> Менеджер зв'яжеться з Вами найближчим часом.";
				$_['entry_fo_send_error'] = "Ваш запит не може бути відправлений. <br /> Зв'яжіться з нами будь-яким іншим зручним способом.";
                
$_['text_home']          = 'Головна';
$_['text_wishlist']      = 'Список побажань (%s)';
$_['text_shopping_cart'] = 'Кошик';
$_['text_category']      = 'Категорії';
$_['text_account']       = 'Обліковий запис';
$_['text_register']      = 'Реєстрація';
$_['text_login']         = 'Вхід';
$_['text_order']         = 'Історія замовлень';
$_['text_transaction']   = 'Оплати';
$_['text_download']      = 'Завантаження';
$_['text_logout']        = 'Вихід';
$_['text_checkout']      = 'Оформлення замовлення';
$_['text_search']        = 'Пошук';
$_['text_all']           = 'Переглянути всі';
$_['text_about']         = 'Про компанію';
$_['text_blog']          = 'Блог';
$_['text_catalog']       = 'Каталог';
$_['text_shops']         = 'Адреси магазинів';
$_['text_delivery']      = 'Доставка і оплата';
$_['text_contacts']      = 'Контакти';
$_['text_special']      = 'Розпродаж';
$_['text_actions']       = 'Акції';
$_['text_news']          = 'Новини';
$_['text_franchise']     = 'Франшиза';